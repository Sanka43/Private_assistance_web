@echo off
setlocal EnableDelayedExpansion
title RuXt AI Desktop Setup

echo ==============================================================
echo              RuXt AI Desktop Companion Installer
echo ==============================================================
echo.

set "INSTALL_DIR=%LOCALAPPDATA%\Programs\RuXt"
set "SRC_DIR=%~dp0"

echo [*] Target Directory: %INSTALL_DIR%
if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"

echo [*] Copying Application Files...
if exist "%SRC_DIR%RuXt-Desktop.exe" (
    copy /Y "%SRC_DIR%RuXt-Desktop.exe" "%INSTALL_DIR%\RuXt-Desktop.exe" >nul
) else (
    echo [ERROR] RuXt-Desktop.exe not found in installer directory!
    pause
    exit /b 1
)

if exist "%SRC_DIR%ruxt.ico" (
    copy /Y "%SRC_DIR%ruxt.ico" "%INSTALL_DIR%\ruxt.ico" >nul
)

if exist "%SRC_DIR%RuXt-Certificate.cer" (
    echo [*] Registering Publisher Trust Certificate...
    certutil -user -addstore "TrustedPublisher" "%SRC_DIR%RuXt-Certificate.cer" >nul 2>&1
)

echo [*] Removing Windows SmartScreen Mark-of-the-Web (Unblocking)...
powershell -NoProfile -Command "Unblock-File -Path '%INSTALL_DIR%\RuXt-Desktop.exe' -ErrorAction SilentlyContinue"

echo [*] Creating Desktop & Start Menu Shortcuts...
powershell -NoProfile -Command "$ws = New-Object -ComObject WScript.Shell; $s = $ws.CreateShortcut([Environment]::GetFolderPath('Desktop') + '\RuXt AI.lnk'); $s.TargetPath = '%INSTALL_DIR%\RuXt-Desktop.exe'; $s.IconLocation = '%INSTALL_DIR%\ruxt.ico,0'; $s.Description = 'RuXt Private AI Executive Assistant'; $s.Save()"
powershell -NoProfile -Command "$ws = New-Object -ComObject WScript.Shell; $programs = [Environment]::GetFolderPath('Programs'); $s = $ws.CreateShortcut($programs + '\RuXt AI.lnk'); $s.TargetPath = '%INSTALL_DIR%\RuXt-Desktop.exe'; $s.IconLocation = '%INSTALL_DIR%\ruxt.ico,0'; $s.Description = 'RuXt Private AI Executive Assistant'; $s.Save()"

echo.
echo ==============================================================
echo       [SUCCESS] RuXt AI Desktop Successfully Installed!
echo ==============================================================
echo Launching RuXt AI Desktop now...

start "" "%INSTALL_DIR%\RuXt-Desktop.exe"

endlocal
exit /b 0
